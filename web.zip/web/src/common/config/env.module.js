define(['angularAMD'], function (ng) {
  'use strict';

  var envConfig = angular.module('config', []);

  envConfig.provider('ENV', function() {
    console.log('EnvConfig.provider:start');

    //set a default configuration
    var envConfig = {
      baseURL: 'http://localhost:',
      adSalPort: "8080",
      mdSalPort: "8181",
      environment: "ENV_DEV",
      getBaseURL: function (salType) {
        return this.baseURL +  (salType === 'AD_SAL' ? this.adSalPort : this.mdSalPort);
      }
    };

    this.$get = ['$location', function($location) {
      var profile = $location.search().profile || 'default';
      var q = jQuery.ajax({
        type: 'GET', url: '/config.json', cache: false, async: false, contentType: 'application/json', dataType: 'json'
      });
      if (q.status === 200) {
        angular.extend(envConfig, angular.fromJson(q.responseText)[profile]);
      }
      envConfig.baseURL = window.location.protocol + "//" + window.location.hostname + ":"
      return envConfig;
    }];
  });

  return envConfig;
});